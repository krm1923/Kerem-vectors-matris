# Linear Algebra 3D Lab

A touch-first English-language workspace for vectors, spans, bases, linear maps and three-variable systems. All mathematical work runs on the device.

## Publish with an iPad

1. Download the ZIP. In Files, tap it to extract the project.
2. In Safari, open https://github.com/krm1923/Kerem-vectors-matris. On the main branch choose **Add file → Upload files**. Select **only the index.html inside ipad-upload** and commit it at the repository root. This replaces the current homepage. GitHub keeps its prior version in commit history.
3. In **Settings → Pages → Build and deployment**, choose **Deploy from a branch → main → / (root)** and save. If your repository already uses GitHub Actions, switch its publishing source to the branch for this single-file route.
4. Open **Visit site** once Pages finishes. The expected address is https://krm1923.github.io/Kerem-vectors-matris/.

The iPad file embeds the compiled application and styles. Uploading the ZIP itself does not deploy the app.

## Develop and deploy the full source

Copy the project contents, including .github/workflows/pages.yml, to the root of the repository. Use the root source index.html for this route. In repository Settings → Pages choose GitHub Actions. Push to main or run Deploy the lab from Actions. Vite sets the base to /Kerem-vectors-matris/. The workflow tests the project and uploads dist. Use Node 22.

    npm ci
    npm test
    npm run dev
    npm run build
    node scripts/package-ipad.mjs

## Controls

Drag blank space to orbit. With Drag points active, touch within 24 CSS pixels of a vector endpoint to select it and move it in the camera-facing plane. Rotate the view to drag along another plane, or use X, Y and Z for precise input. A second contact switches to pan and zoom. Orbit mode disables endpoint capture. On smaller screens the menu opens over the scene. Changes save in this browser. Workspace exports and imports mathematical configurations.

## Modules and conventions

- Vector Playground uses the selected vector as the first operand. Direction is a unit vector.
- Linear Combinations uses the first three included vectors in list order. Drag coefficient sliders to update the resulting vector or trace the weighted sum.
- Span and Linear Independence use all included vectors. Coral nonpivot vectors are dependent on preceding pivot vectors.
- Basis & Dimension chooses pivot columns, extends them with standard basis directions and solves for target coordinates in their span.
- Subspaces uses generator vectors, the null or column space of a matrix, or two homogeneous planes specified by their normals.
- Matrix Transformations overlays the original and mapped unit cube and vectors. Animation interpolates linearly from the identity to the chosen map. The endpoint is the specified transformation.
- Gaussian Elimination steps through elementary operations on a one- to three-row augmented matrix in x, y and z. REF and RREF navigate to the corresponding step. Manual edits operate on the displayed step. Add multiple means target ← target + factor × source.
- Equation Systems displays individual planes, pairwise line intersections and the common solution in gold. Free parameters are s, t and u. An all-zero equation with zero right-hand side represents all space.
- Change of Basis uses the columns of B as the custom basis, with v = B[v]ᴮ. The target stays fixed during the frame transition.
- Two UW presets reproduce the vector sets from the study material. In the parameter-dependent span preset, change the third vector's Z value between 2 and 3.

## Implementation and checks

Vite bundles native JavaScript modules. The lightweight Canvas 2D renderer projects real 3D coordinates and handles camera gestures directly. Scene rendering uses requestAnimationFrame on demand. There are no runtime package, font or API requests. Numerical work uses floating-point partial pivoting with a column-relative threshold of 1e-10. Measurements are rounded for display. Very ill-conditioned inputs can change numerical rank near the tolerance. The visible lattice and planes are finite samples of unbounded mathematical sets.

The Node suite checks preset validity, spans, UW examples, coordinate round trips, orientation, solution classes, elimination history and simulated tablet pointer sequences. All ten module panels were opened in desktop Chrome. Physical iPad Safari gesture behavior, keyboard behavior and native full-screen transitions still require device verification.
