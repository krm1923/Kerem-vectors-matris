import {readFile,writeFile,mkdir} from 'node:fs/promises';
const base='/Kerem-vectors-matris/';
let html=await readFile('dist/index.html','utf8');
for(const tag of html.matchAll(/<script[^>]+src="([^"]+)"[^>]*><\/script>/g)){
 const js=await readFile('dist/'+tag[1].replace(base,''),'utf8');
 html=html.replace(tag[0],()=>'<script type="module">'+js.replaceAll('</script','<\\/script')+'</script>');
}
for(const tag of html.matchAll(/<link[^>]+href="([^"]+\.css)"[^>]*>/g)){
 const css=await readFile('dist/'+tag[1].replace(base,''),'utf8');html=html.replace(tag[0],()=>'<style>'+css+'</style>');
}
await mkdir('ipad-upload',{recursive:true});await writeFile('ipad-upload/index.html',html);
