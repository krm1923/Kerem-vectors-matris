import {O,I,add,sub,scale,dot,norm,unit,tr,mul,det,reduce,solve,basis,fmt,tuple} from './math.js';
import {modules,ops,spaces,maps,presets,fresh,operation,selected,spanBasis,coords,solutionText,validate} from './model.js';
import {viewport,colors} from './scene.js';
const $=s=>document.querySelector(s),panel=$('#panel'),dialog=$('#dialog'),db=$('#dialogBody');
let s=fresh(),step=0,t=1,animation=0,from=0,to=1,factor=1,manual=[],future=[];
try{let saved=JSON.parse(localStorage.getItem('vectorlab-v1'));if(validate(saved))s=saved}catch{}
const color=i=>colors[i%colors.length], current=()=>s.vs[s.sel], active=()=>selected(s).map(x=>x.v);
const rows=()=>s.module===7?reduce(s.eq,3).steps[step]?.m||s.eq:s.eq;
const derivedSpace=()=>s.space<2?active().slice(0,s.space+1):s.space===2?solve(s.M.map(r=>[...r,0])).dirs:s.space===3?tr(s.M):solve(s.M.slice(0,2).map(r=>[...r,0])).dirs;
function draw(g){
 const m=s.module,A=active(),bs=spanBasis(s),gold='#f6ce79';
 if(m>=2&&m<=4)g.surface(A);
 if(m===5){if(s.space===4)s.M.slice(0,2).forEach((r,i)=>g.surface(solve([[...r,0]]).dirs,O,color(i)));g.surface(derivedSpace(),O,s.space===4?gold:color(0))}
 if(m===7||m===8){const r=rows();r.forEach((row,i)=>{const p=solve([row]);if(!p.none)g.surface(p.dirs,p.base,color(i))});for(let i=0;i<r.length;i++)for(let j=i+1;j<r.length;j++){const p=solve([r[i],r[j]]);if(!p.none&&p.dirs.length===1)g.surface(p.dirs,p.base,'#869ca3')}
 const p=solve(r);if(!p.none){g.surface(p.dirs,p.base,gold);if(!p.dirs.length){g.point(p.base,gold,6);g.label(p.base,tuple(p.base),gold)}}return}
 if(m===9){tr(s.B).forEach((v,i)=>g.arrow(add(scale(I[i],1-t),scale(v,t)),color(i),'b'+(i+1)));g.arrow(s.target,gold,'v',O,-1,true);return}
 if(m===6){const edge=(map,c)=>{for(let i=0;i<8;i++){const p=I.map((_,j)=>(i>>j)&1);for(let j=0;j<3;j++)if(!p[j])g.path([map(p),map(add(p,I[j]))],c,1.5)}};edge(v=>v,'#89969b');const f=v=>add(scale(v,1-t),scale(mul(s.M,v),t));edge(f,det(s.M)<0?'#f49c91':gold);s.vs.forEach((x,i)=>g.arrow(f(x.v),gold,'A·'+x.name))}
 if(m===1){let p=O;A.slice(0,3).forEach((v,i)=>{let d=scale(v,s.coeff[i]*t);g.arrow(d,color(i),'',p);p=add(p,d)});g.arrow(p,gold,'v')}
 if(m===0){const a=current().v,b=s.vs[s.other].v,r=operation(s);if(Array.isArray(r)){if(s.op===1){g.path([a,r,b],'#cad5c7',1.5,[5,5]);g.arrow(scale(b,t),color(s.other),'',a);g.arrow(add(a,scale(b,t)),gold,'sum')}else g.arrow(r,gold,'result')}if(s.op===7&&Array.isArray(r))g.path([a,r],'#e8ce89',1,[4,4])}
 if(m===5&&s.space>1)return;
 s.vs.forEach((x,i)=>{const limited=(m>=1&&m<=5)&&!x.on;let c=limited?'#677178':m===3&&!bs.includes(x)?'#ff997f':color(i);g.arrow(x.v,c,x.name,O,i,s.sel===i)});
 if(m===4)g.arrow(s.target,gold,'target',O,-1);
}
const view=viewport($('#canvas'),draw,{select(i){if(i>=0){s.sel=i;layout()}},move(i,v){if(i<0)s.target=v;else s.vs[i].v=v;layout()}});
function el(tag,parent,text,cls){let e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;parent.append(e);return e}
function btn(p,label,fn,cls){const b=el('button',p,label,cls);b.onclick=fn;return b}
function group(title){let e=el('section',panel,undefined,'group');el('h3',e,title);return e}
const row=p=>el('div',p,undefined,'row');
function select(p,items,i,fn,label){let e=el('select',p);e.ariaLabel=label;items.forEach((x,j)=>{let o=el('option',e,x);o.value=j});e.selectedIndex=i;e.onchange=()=>fn(+e.value);return e}
function number(p,v,fn,label){let e=el('input',p);e.type='number';e.step='any';e.inputMode='decimal';e.value=v;e.ariaLabel=label;e.onchange=()=>{const x=e.valueAsNumber;if(Number.isFinite(x)&&Math.abs(x)<=1e8){fn(x);layout()}else e.value=v};return e}
function slider(p,name,v,fn){let r=el('label',p,undefined,'slider');el('span',r,name);let e=el('input',r);e.type='range';let lim=Math.max(6,Math.ceil(Math.abs(v)));e.min=-lim;e.max=lim;e.step=.05;e.value=v;e.ariaLabel=name+' slider';let n=number(r,v,fn,name+' value');e.oninput=()=>{fn(+e.value);n.value=e.value;refresh()};e.onchange=layout}
function matrix(p,m,change=()=>{}){const a=el('div',p,undefined,'matrix');a.style.gridTemplateColumns='repeat('+m[0].length+',1fr)';m.forEach((r,i)=>r.forEach((v,j)=>number(a,v,x=>{m[i][j]=x;change()},'Row '+(i+1)+' column '+(j+1))))}
function modal(title){db.replaceChildren();el('h3',db,title);dialog.showModal()}
function item(title,fn){btn(db,title,()=>{dialog.close();fn()},'item')}
function notify(message){$('#toast').textContent=message;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('#toast').textContent='',2500)}
function resetSteps(){step=0;manual=[];future=[];from=0;to=Math.min(1,s.eq.length-1)}
function animate(){cancelAnimationFrame(animation);let start=performance.now();function frame(now){t=Math.min(1,(now-start)/950);view.render();if(t<1)animation=requestAnimationFrame(frame)}frame(start)}
function nav(i){s.module=i;step=0;t=1;cancelAnimationFrame(animation);document.body.classList.remove('showNav');layout()}
function addVector(v,name){if(s.vs.length>=64)return notify('64-vector limit');s.vs.push({v:[...v],name:name.slice(0,40),on:true});s.sel=s.vs.length-1;layout()}
function vectors(){const p=group('Scene vectors');s.vs.forEach((x,i)=>{let b=btn(p,'',()=>{s.sel=i;layout()},'vec'+(s.sel===i?' sel':''));let d=el('span',b,undefined,'dot');d.style.background=color(i);el('span',b,x.name);el('code',b,tuple(x.v));if(s.module>=1&&s.module<=5){const check=el('input',b);check.type='checkbox';check.checked=x.on;check.ariaLabel='Include '+x.name;check.onclick=e=>{e.stopPropagation();x.on=check.checked;layout()}}});
 let r=row(p);btn(r,'+ Add',()=>addVector([1,0,0],'v'+(s.vs.length+1)));btn(r,'Duplicate',()=>addVector(current().v,current().name+'′'));btn(r,'Edit…',()=>{modal('Edit vector');let input=el('input',db);input.value=current().name;input.maxLength=40;input.ariaLabel='Vector name';item('Save name',()=>{current().name=input.value.trim()||'v';layout()});if(s.vs.length>1)item('Remove vector',()=>{s.vs.splice(s.sel,1);s.sel=Math.min(s.sel,s.vs.length-1);s.other=Math.min(s.other,s.vs.length-1);layout()})});
 const q=group('Coordinates · '+current().name);current().v.forEach((v,i)=>slider(q,'XYZ'[i],v,x=>current().v[i]=x))}
function target(){let p=group('Target vector');s.target.forEach((v,i)=>slider(p,'XYZ'[i],v,x=>s.target[i]=x))}
function workspace(){let p=group('Augmented matrix · [x y z | b]');matrix(p,s.eq,resetSteps);let r=row(p);if(s.eq.length<3)btn(r,'+ Equation',()=>{s.eq.push([0,0,1,1]);resetSteps();layout()});if(s.eq.length>1)btn(r,'− Equation',()=>{s.eq.pop();resetSteps();layout()});
 if(s.module===8)return;const a=reduce(s.eq,3),q=group('Elimination steps'),snap=a.steps[step];el('div',q,(step+1)+' / '+a.steps.length+' · '+snap.label);snap.m.forEach(r=>el('div',q,r.map(fmt).join('   '),'result'));let controls=row(q);
 for(const [label,k] of [['← Back',step-1],['Forward →',step+1],['REF',a.ref],['RREF',a.steps.length-1]]){btn(controls,label,()=>{step=k;layout()}).disabled=k<0||k>=a.steps.length||k===step}
 const h=group('Manual row operation'),rr=row(h),names=s.eq.map((_,i)=>'R'+(i+1));select(rr,names,to,i=>to=i,'Target row');select(rr,names,from,i=>from=i,'Source row');number(h,factor,x=>factor=x,'Row factor');
 const act=op=>{if((op!=='Scale'&&from===to)||(op==='Scale'&&factor===0))return notify('Use distinct rows and a nonzero scale factor');manual.push(structuredClone(s.eq));future=[];s.eq=structuredClone(snap.m);if(op==='Swap')[s.eq[from],s.eq[to]]=[s.eq[to],s.eq[from]];else s.eq[to]=op==='Scale'?scale(s.eq[to],factor):add(s.eq[to],scale(s.eq[from],factor));step=0;layout()};rr.append();let buttons=row(h);['Swap','Scale','Add multiple'].forEach(o=>btn(buttons,o,()=>act(o)));btn(buttons,'Undo',()=>{future.push(s.eq);s.eq=manual.pop();step=0;layout()}).disabled=!manual.length;btn(buttons,'Redo',()=>{manual.push(s.eq);s.eq=future.pop();step=0;layout()}).disabled=!future.length}
function layout(){panel.replaceChildren();const m=s.module;$('#title').textContent=modules[m];$('#moduleTag').textContent='MODULE '+String.fromCharCode(65+m)+' / ℝ³';[...$('#modules').children].forEach((b,i)=>b.classList.toggle('active',i===m));
 if(m<=6&&(m!==5||s.space<2))vectors();
 if(m===0){let p=group('Vector operation');select(p,ops,s.op,i=>{s.op=i;layout()},'Operation');if(s.op&&s.op!==3){let r=row(p);el('span',r,'Second vector');select(r,s.vs.map(x=>x.name),s.other,i=>{s.other=i;layout()},'Second operand')}if(s.op===3)slider(p,'k',s.k,x=>s.k=x);if(s.op===1)btn(p,'▶ Animate addition',animate)}
 if(m===1){let p=group('Coefficients');active().slice(0,3).forEach((_,i)=>slider(p,'abc'[i],s.coeff[i],x=>s.coeff[i]=x));btn(p,'▶ Trace combination',animate)}
 if(m===4){let p=group('Basis extension');btn(p,'Extend to a basis of ℝ³',()=>{const a=active();for(const v of I)if(basis([...a,v]).length>basis(a).length){a.push(v);addVector(v,'e'+(I.indexOf(v)+1))}layout()});target()}
 if(m===5){const p=group('Subspace');select(p,spaces,s.space,i=>{s.space=i;layout()},'Subspace type');if(s.space>=2){const q=group(s.space===4?'Plane normals':'Defining matrix');matrix(q,s.space===4?s.M.slice(0,2):s.M)}}
 if(m===6){let p=group('Transformation matrix');select(p,['Custom',...Object.keys(maps)],Object.values(maps).findIndex(a=>JSON.stringify(a)===JSON.stringify(s.M))+1,i=>{if(i){s.M=structuredClone(Object.values(maps)[i-1]);animate()}layout()},'Transformation preset');matrix(p,s.M);btn(p,'▶ Animate transformation',animate)}
 if(m===7||m===8)workspace();
 if(m===9){const p=group('Basis vectors · columns of B');matrix(p,s.B);let r=row(p);btn(r,'Standard basis',()=>{s.B=structuredClone(I);layout()});btn(r,'▶ Transition',animate);target()}
 let q=group('Live measurements');el('div',q,undefined,'result').id='measure';refresh()}
function refresh(){const m=s.module,v=current().v,A=active(),bs=spanBasis(s),lines=[];
 if(m===0){lines.push('Magnitude   '+fmt(norm(v)),'Direction   '+(norm(v)?tuple(unit(v)):'Undefined'));const r=operation(s);if(r!==null)lines.push(ops[s.op]+'   '+(Array.isArray(r)?tuple(r):r))}
 if(m===1){const a=selected(s).slice(0,3);lines.push('v = '+(a.map((x,i)=>s.coeff[i]+'·'+x.name).join(' + ')||'0'),'v = '+tuple(a.reduce((p,x,i)=>add(p,scale(x.v,s.coeff[i])),O)))}
 if(m>=2&&m<=4){lines.push('Rank '+bs.length+' · '+['Origin','Line · collinear','Plane · coplanar','Full space ℝ³'][bs.length]);if(m===3){lines.push(A.length===bs.length?'LINEARLY INDEPENDENT':'LINEARLY DEPENDENT');if(A.length===3)lines.push('det = '+fmt(det(A)));let dep=selected(s).filter(x=>!bs.includes(x));if(dep.length)lines.push('Nonpivot · '+dep.map(x=>x.name).join(', '))}
 if(m===4){let p=coords(bs.map(x=>x.v),s.target);lines.push('Basis   {'+bs.map(x=>x.name).join(', ')+'}','[target]ᴮ   '+(p.none?'Outside span':tuple(p.base)))}}
 if(m===5){const b=derivedSpace();lines.push('Dimension '+basis(b).length,...basis(b).map(i=>'Basis vector   '+tuple(b[i])))}
 if(m===6){let d=det(s.M);lines.push('Signed volume   '+fmt(d),basis(tr(s.M)).length<3?'Collapsed volume':d<0?'Coral · orientation reversed':'Gold · orientation preserved','A·'+current().name+' = '+tuple(mul(s.M,v)))}
 if(m===7||m===8){const p=solve(rows());lines.push(solutionText(p),'Rank '+p.piv.length,'Pivot columns   '+(p.piv.map(i=>i+1).join(', ')||'none'),'Free columns   '+(p.free.map(i=>'xyz'[i]).join(', ')||'none'))}
 if(m===9){const p=coords(tr(s.B),s.target);lines.push('Standard   '+tuple(s.target));if(basis(tr(s.B)).length===3){lines.push('Custom   '+tuple(p.base),'Standard → custom · B⁻¹');tr(I.map(e=>coords(tr(s.B),e).base)).forEach(r=>lines.push(tuple(r)))}else lines.push('Singular columns · choose a basis')}
 const out=$('#measure');if(out){out.replaceChildren();lines.forEach(l=>el('div',out,l))}document.querySelectorAll('.vec code').forEach((c,i)=>c.textContent=tuple(s.vs[i].v));$('#legend').textContent=m===7||m===8?'Gold · common solution':m===9?'Gold · fixed vector':s.vs.length+' scene vector'+(s.vs.length===1?'':'s');view.render();clearTimeout(refresh.save);refresh.save=setTimeout(()=>{try{localStorage.setItem('vectorlab-v1',JSON.stringify(s))}catch{notify('Local save unavailable · export JSON')}},180)}
modules.forEach((name,i)=>{let b=btn($('#modules'),'',()=>nav(i));el('i',b,['↗','Σ','▱','⋈','β','∩','▦','≋','≡','⇄'][i]);el('span',b,name)});
$('#navToggle').onclick=()=>document.body.classList.toggle(innerWidth<=1100?'showNav':'hideNav');
function toolbar(){const p=$('#toolbar');p.replaceChildren();['Grid','Axes','Labels','Planes','Perspective'].forEach(key=>btn(p,key==='Perspective'?(view.opts[key]?'Perspective':'Orthographic'):key,()=>{view.opts[key]=!view.opts[key];toolbar();view.render()},view.opts[key]?'active':''));btn(p,'↺ Reset',()=>view.reset());$('#cameraBadge').textContent='◈  '+(view.opts.Perspective?'PERSPECTIVE':'ORTHOGRAPHIC');$('#drag').classList.toggle('active',view.opts.drag);$('#orbit').classList.toggle('active',!view.opts.drag)}
$('#orbit').onclick=()=>{view.opts.drag=false;toolbar()};$('#drag').onclick=()=>{view.opts.drag=true;toolbar()};
$('#full').onclick=async()=>{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen){try{await document.documentElement.requestFullscreen()}catch{document.body.classList.toggle('focus')}}else document.body.classList.toggle('focus')};
$('#preset').onclick=()=>{modal('Example configurations');presets.forEach((x,i)=>item(x,()=>{s=fresh(i);resetSteps();nav(s.module);view.reset()}))};
$('#files').onclick=()=>{modal('Workspace');item('Export configuration (.json)',()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(s,null,2)],{type:'application/json'}));let a=document.createElement('a');a.href=url;a.download='vector-lab.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000)});item('Import configuration…',()=>$('#importFile').click());el('p',db,'Changes are saved automatically on this device.')};
$('#importFile').onchange=async e=>{const f=e.target.files[0];try{if(!f||f.size>250000)throw Error();const obj=JSON.parse(await f.text());if(!validate(obj))throw Error();s=obj;resetSteps();nav(s.module);view.reset();notify('Configuration loaded')}catch{notify('Invalid lab configuration')}e.target.value=''};
resetSteps();toolbar();layout();
