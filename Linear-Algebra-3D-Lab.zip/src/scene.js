import {O,I,add,sub,scale,dot,norm,unit,cross,basis} from './math.js';
export const colors=['#81e2b7','#b29aff','#ffaf77','#65c8ef','#f28db8','#e2ce7a'];
export function viewport(canvas,build,callbacks){
 const ctx=canvas.getContext('2d'),points=new Map(),home={yaw:.76,pitch:.43,zoom:1,px:0,py:0};
 const cam={...home},opts={Grid:true,Axes:true,Labels:true,Planes:true,Perspective:true,drag:true};
 let w,h,s,R,U,D,hits=[],held=null,frame=0,dirty=false;
 function setup(){const box=canvas.getBoundingClientRect();w=box.width;h=box.height;const d=Math.min(devicePixelRatio||1,2);if(canvas.width!==Math.round(w*d)||canvas.height!==Math.round(h*d)){canvas.width=Math.round(w*d);canvas.height=Math.round(h*d)}ctx.setTransform(d,0,0,d,0,0);s=Math.min(w,h)*.094*cam.zoom;const c=Math.cos(cam.yaw),a=Math.sin(cam.yaw),p=Math.sin(cam.pitch),q=Math.cos(cam.pitch);R=[c,-a,0];U=[-a*p,-c*p,q];D=[a*q,c*q,p]}
 function project(v){const depth=dot(v,D),k=opts.Perspective?32/(32-depth):1;return [w*.5+cam.px+s*k*dot(v,R),h*.54+cam.py-s*k*dot(v,U),depth,k]}
 function path(vs,color,width=1,dash=[],fill=false){const ps=vs.map(project);if(ps.some(p=>p[3]<=0))return;ctx.beginPath();ps.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.setLineDash(dash);ctx.lineWidth=width;if(fill){ctx.closePath();ctx.fillStyle=fill;ctx.fill()}ctx.strokeStyle=color;ctx.stroke();ctx.setLineDash([])}
 function label(v,t,color,dx=8,dy=-8){if(!opts.Labels)return;const [x,y,,k]=project(v);if(k<=0)return;ctx.font='600 13px ui-monospace, monospace';ctx.strokeStyle='#151a20';ctx.lineWidth=4;ctx.strokeText(t,x+dx,y+dy);ctx.fillStyle=color;ctx.fillText(t,x+dx,y+dy)}
 function point(v,c,r=4){const [x,y,,k]=project(v);if(k<=0)return;ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.fillStyle=c;ctx.fill()}
 function arrow(v,c,name,start=O,id=null,selected=false){const end=add(start,v),a=project(start),b=project(end);if(a[3]<=0||b[3]<=0)return;path([start,end],c,selected?3.5:2.7);const angle=Math.atan2(b[1]-a[1],b[0]-a[0]);ctx.save();ctx.translate(b[0],b[1]);ctx.rotate(angle);ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-14,5);ctx.lineTo(-11,0);ctx.lineTo(-14,-5);ctx.fill();ctx.restore();if(id!==null){hits.push({v:end,id,p:b});if(selected){ctx.strokeStyle=c;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(b[0],b[1],10,0,2*Math.PI);ctx.stroke()}}label(end,name,c,12,-10)}
 function plane(a,b,o,c){if(!opts.Planes)return;const u=scale(unit(a),5),v=scale(unit(sub(b,scale(unit(a),dot(b,unit(a))))),5);path([add(o,add(u,v)),add(o,sub(u,v)),sub(o,add(u,v)),add(o,sub(v,u))],c+'70',1,[],c+'22')}
 function surface(vs,o=O,c=colors[0]){const bs=basis(vs).map(i=>vs[i]);if(!bs.length){point(o,c);return}if(bs.length===1){const v=scale(unit(bs[0]),12);path([sub(o,v),add(o,v)],c,2);return}if(bs.length===2){plane(...bs,o,c);return}if(opts.Planes)for(let i=-3;i<=3;i++)for(let j=-3;j<=3;j++)path([add(o,[i,j,-3]),add(o,[i,j,3])],c+'40')}
 function draw(){dirty=false;setup();ctx.clearRect(0,0,w,h);hits=[];if(opts.Grid)for(let i=-9;i<=9;i++){path([[i,-9,0],[i,9,0]],'#334149',.75);path([[-9,i,0],[9,i,0]],'#334149',.75)}
 if(opts.Axes)I.forEach((v,i)=>{const c=['#d88b91','#80bba2','#88a8d3'][i];path([scale(v,-8),scale(v,8)],c+'96');const t=Math.min(4,Math.min(w,h)/Math.max(s,1)*.37);label(scale(v,t),'XYZ'[i],c)});
 build({arrow,plane,path,point,surface,label});point(O,'#b8c6c7',3)}
 function render(){if(!dirty){dirty=true;frame=requestAnimationFrame(draw)}}
 new ResizeObserver(render).observe(canvas);
 const local=e=>{const b=canvas.getBoundingClientRect();return [e.clientX-b.left,e.clientY-b.top]};
 canvas.onpointerdown=e=>{canvas.setPointerCapture(e.pointerId);const p=local(e);points.set(e.pointerId,p);held=null;if(points.size===1&&opts.drag){const hit=hits.map(h=>({...h,d:Math.hypot(h.p[0]-p[0],h.p[1]-p[1])})).filter(h=>h.d<24).sort((a,b)=>a.d-b.d)[0];if(hit){held=hit;callbacks.select(hit.id)}}};
 canvas.onpointermove=e=>{if(!points.has(e.pointerId))return;const old=points.get(e.pointerId),p=local(e),dx=p[0]-old[0],dy=p[1]-old[1];if(points.size===2){const other=[...points].find(([id])=>id!==e.pointerId)[1];const dist=q=>Math.hypot(q[0]-other[0],q[1]-other[1]);cam.zoom=Math.min(8,Math.max(.12,cam.zoom*dist(p)/Math.max(1,dist(old))));cam.px+=dx/2;cam.py+=dy/2}else if(points.size===1&&held){const k=s*project(held.v)[3];held.v=add(held.v,add(scale(R,dx/k),scale(U,-dy/k))).map(x=>+x.toFixed(3));callbacks.move(held.id,held.v)}else if(points.size===1){cam.yaw-=dx*.008;cam.pitch=Math.max(-1.5,Math.min(1.5,cam.pitch+dy*.008))}points.set(e.pointerId,p);render()};
 canvas.onpointerup=canvas.onpointercancel=canvas.onlostpointercapture=e=>{points.delete(e.pointerId);held=null};
 canvas.onwheel=e=>{e.preventDefault();cam.zoom=Math.min(8,Math.max(.12,cam.zoom*Math.exp(-e.deltaY*.001)));render()};
 return {render,opts,reset(){Object.assign(cam,home);render()}}
}
