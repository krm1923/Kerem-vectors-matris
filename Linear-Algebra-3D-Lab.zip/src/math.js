export const O=[0,0,0], I=[[1,0,0],[0,1,0],[0,0,1]];
export const add=(a,b)=>a.map((x,i)=>x+b[i]), scale=(a,k)=>a.map(x=>x*k), sub=(a,b)=>add(a,scale(b,-1)), dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0), norm=a=>Math.hypot(...a), unit=a=>norm(a)?scale(a,1/norm(a)):a, cross=([a,b,c],[x,y,z])=>[b*z-c*y,c*x-a*z,a*y-b*x], tr=m=>m[0]?.map((_,i)=>m.map(r=>r[i]))||[], mul=(m,v)=>m.map(r=>dot(r,v)), det=m=>dot(m[0],cross(m[1],m[2]));
// Each pivot is compared with its original column scale. Record only invertible row operations.
export function reduce(matrix,n=matrix[0]?.length||0){
 const m=matrix.map(r=>[...r]), tol=Array.from({length:n},(_,j)=>Math.max(...m.map(r=>Math.abs(r[j])),0)*1e-10), piv=[], steps=[];
 const record=label=>steps.push({label,m:m.map(r=>[...r])});
 record('Initial matrix');
 const eliminate=(i,k,j)=>{const a=m[i][j]/m[k][j];if(!a)return;m[i]=sub(m[i],scale(m[k],a));m[i][j]=0;record('R'+(i+1)+' ← R'+(i+1)+' − ('+fmt(a)+') R'+(k+1))};
 for(let j=0;j<n&&piv.length<m.length;j++){const k=piv.length;let p=k;for(let i=k+1;i<m.length;i++)if(Math.abs(m[i][j])>Math.abs(m[p][j]))p=i;if(Math.abs(m[p][j])<=tol[j])continue;
 if(p!==k){[m[k],m[p]]=[m[p],m[k]];record('Swap R'+(p+1)+' and R'+(k+1))}
 piv.push(j);for(let i=k+1;i<m.length;i++)eliminate(i,k,j)}
 const ref=steps.length-1;
 for(let k=piv.length-1;k>=0;k--){const j=piv[k],a=m[k][j];if(a!==1){m[k]=scale(m[k],1/a);m[k][j]=1;record('R'+(k+1)+' ÷ '+fmt(a))}for(let i=0;i<k;i++)eliminate(i,k,j)}
 return {m,piv,steps,ref}
}
export function solve(rows,n=3){const {m,piv}=reduce(rows,n),free=Array.from({length:n},(_,i)=>i).filter(i=>!piv.includes(i)),base=Array(n).fill(0);
 const bScale=Math.max(...rows.map(r=>Math.abs(r[n])),0);
 const none=m.slice(piv.length).some(r=>Math.abs(r[n])>bScale*1e-9);
 piv.forEach((j,i)=>base[j]=m[i][n]);
 return {none,base,free,dirs:free.map(f=>{let v=Array(n).fill(0);v[f]=1;piv.forEach((j,i)=>v[j]=-m[i][f]);return v}),piv}}
export function basis(vs){if(!vs.length)return [];return reduce(tr(vs)).piv}
export const fmt=x=>Math.abs(x)>0&&(Math.abs(x)<0.001||Math.abs(x)>=1e5)?x.toExponential(2):String(+x.toFixed(3)), tuple=v=>'('+v.map(fmt).join(', ')+')';
