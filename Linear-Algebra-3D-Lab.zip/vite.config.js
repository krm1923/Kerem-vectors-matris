export default {base:'/Kerem-vectors-matris/'}
